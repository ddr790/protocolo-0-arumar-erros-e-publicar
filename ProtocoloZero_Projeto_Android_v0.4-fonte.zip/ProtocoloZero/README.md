# PROTOCOLO ZERO — SURVIVAL OS
Versão do projeto: **0.4.0 (fonte em atualização)**

Aplicativo Android nativo em Kotlin + Jetpack Compose, planejado para funcionamento offline e armazenamento local.

## Recursos incluídos
- Painel inicial.
- Inventário de suprimentos e checklist persistidos em Room.
- Calculadoras simples de autonomia de água e energia.
- Contatos nacionais de emergência do Brasil (discador do Android).
- Cadastro local de contatos familiares com atalho para discagem.
- Lanterna via flash da câmera, quando o aparelho oferece o hardware e a permissão.
- Manuais educativos iniciais.
- Cinema Offline com importação de vídeos, Room, player Media3, favoritos, pesquisa e retomada de reprodução.
- Lanterna SOS com flash, tela colorida e padrão Morse.
- Jogo 2048 simplificado; tabuleiro e melhor pontuação são salvos localmente.
- Exportação e importação de backup JSON para listas, contatos e preferências selecionadas.

## Backup
Na aba **Ferramentas > Sobre**, use Exportar Backup para criar um arquivo JSON. Para recuperar, use Importar Backup e selecione um backup criado pelo aplicativo. Importar restaura preferências e listas; por segurança, feche e reabra o aplicativo para recarregar as telas e o banco local após a restauração.

## Requisitos
- Android 8.0 (API 26) ou superior.
- JDK 17.
- Android SDK 35 e Gradle compatível para compilar.

## Compilação
Abra a pasta do projeto no Android Studio e aguarde a sincronização do Gradle. Depois execute a tarefa `assembleDebug`. O APK de depuração, se a compilação terminar sem erros, ficará em `app/build/outputs/apk/debug/app-debug.apk`.

## Limitações conhecidas
- Este pacote contém o **projeto-fonte**, não um APK compilado.
- O ambiente desta sessão não possui Android SDK nem Gradle instalados; portanto não foi possível compilar nem executar testes em dispositivo/emulador.
- A compatibilidade de codecs, faixas de áudio e legendas depende do aparelho e do arquivo.
- O 2048 ainda é uma implementação simplificada por toque, não o jogo completo com gestos.
- Não há mapas offline, previsão meteorológica/solar ao vivo, rádio FM garantido, comunicação por rádio ou mensageria independente.
- A importação de backup orienta reabrir o app para recarregar as telas e sincronizar o banco Room.
- O conteúdo dos manuais é educativo e não substitui orientações oficiais ou profissionais.

Consulte `docs/RELATORIO_TECNICO_v0.4.md` para alterações, limitações e estado real dos testes.
