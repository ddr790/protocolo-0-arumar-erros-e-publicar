# PROTOCOLO ZERO — relatório técnico da revisão v0.4

Data: 14/11/2026

## Base preservada

A base foi o ZIP `ProtocoloZero_Projeto_Android_v0.3.zip`. O app existente foi mantido: painel, estoque, plano/checklist, calculadoras, manuais, 2048 simplificado, contatos, backup JSON e fluxo antigo de vídeo continuam no código.

Foi corrigida a chamada de `ToolsScreen`, que não fornecia os dois argumentos obrigatórios de contatos familiares.

## Alterações implementadas no código-fonte

### Cinema Offline
- Nova seção `CINEMA OFFLINE`.
- Importação de um ou vários vídeos pelo Storage Access Framework (`OpenMultipleDocuments`).
- Permissões persistentes de leitura dos URIs escolhidos pelo usuário.
- Cadastro de título e duração quando os metadados são legíveis.
- Organização local nas categorias Filmes, Séries, Desenhos e Vídeos.
- Pesquisa, favoritos e remoção da biblioteca.
- Player integrado com AndroidX Media3/ExoPlayer.
- Controles nativos de reprodução, barra de progresso e tela de vídeo do PlayerView.
- Controle de volume, brilho da tela e velocidade (0,5x a 2x).
- Posição de reprodução salva a cada 5 segundos e ao sair do player.
- Banco Room existente atualizado da versão 1 para 2 com migração SQL não destrutiva; inventário e checklist existentes não são descartados.

Limitações: o app registra arquivos selecionados, mas não faz scraping de capas ou sinopses online. A disponibilidade de MKV, codecs, áudio e legendas depende do Android e dos decodificadores presentes no aparelho. Não há ainda extração de miniaturas, gerenciamento completo de temporadas/episódios, nem editor de metadados completo.

### Lanterna SOS Extrema
- Nova seção `LANTERNA SOS`.
- Verificação do flash traseiro e solicitação de permissão CAMERA.
- Potência máxima de torch quando o Android 13+ e o hardware expõem controle de intensidade; fallback para o nível padrão do dispositivo.
- Padrão SOS em flash traseiro, tela colorida e modo combinado.
- Cores de tela: vermelho, azul, amarelo e branco. O LED traseiro permanece branco.
- Botão de parada, mensagem SOS e indicador do estado do flash.
- Temporização implementada em coroutine, sem bloquear a interface.
- O flash é desligado quando a tela sai de composição/é encerrada.

Limitações: não foi executado em hardware real; comportamento e intensidade variam por fabricante. O app não pode superar a potência física do LED. Luz intermitente pode afetar pessoas fotossensíveis e aquecer o aparelho.

## Banco de dados

A tabela `offline_media` foi adicionada ao `protocolo_zero.db`, com migração `1 -> 2`. A nova tabela registra URI, título, categoria, duração, posição, favorito e data de importação. Os dados antigos de estoque e checklist permanecem nas tabelas originais.

## Análise dos arquivos externos

### Pluto TV Kodi 1.6.0
É um addon Python para Kodi (`xbmc.python` 3.0), com dependências `requests`, `routing`, `simplecache`, `inputstreamhelper`, `kodi_six` e serviço opcional IPTV Manager. O código usa APIs HTTP da Pluto TV para guia, canais e VOD. Não é biblioteca Android nem pode ser importado diretamente em Kotlin/Compose. Nenhum código do addon foi executado ou transplantado. Uma integração Android legítima precisaria usar canais oficiais/API autorizada e respeitar disponibilidade regional, autenticação, DRM e licenças.

### repo-plugins-master.zip
O conteúdo é o branch não público/documental do repositório Kodi: README, CONTRIBUTING, modelos de issue/PR e metadados. Não contém addons para classificar ou integrar.

### Jogos
- **FNAF AR Special Delivery**: APK Unity com bibliotecas nativas ARM64, ARCore e componentes Firebase. Isso indica dependências de realidade aumentada e serviços; não prova que o jogo funcione offline.
- **Snake.io**: APK com múltiplos DEX e bibliotecas Firebase/Crashlytics/Analytics e bibliotecas de anúncios/telemetria. O pacote não fornece fonte nem comprovação de modo offline.
- **XAPK identificado como Subway City**: o `manifest.json` declara nome `Subway City`, versão 2.6.3, minSdk 29, targetSdk 36, permissões INTERNET, BILLING, CHECK_LICENSE e split `armeabi_v7a`. O pacote contém APK base e configuração ARMv7; não foi fornecida variante ARM64 no split. A compatibilidade no tablet ARM64 depende do suporte do sistema a apps 32-bit. Não foi comprovado modo offline.

Os jogos não foram alterados nem incorporados ao aplicativo. Não foram removidas verificações de licença, compras ou proteções.

## Verificação e estado da compilação

Foram feitas verificações estáticas de arquivos, dependências, rotas, presença da migração Room e equilíbrio básico de delimitadores do código. Os arquivos de projeto foram modificados e empacotados.

**Não foi possível compilar nem executar testes Android nesta sessão:** não há Gradle, Gradle Wrapper, Android SDK, `adb`, `aapt` ou Kotlin compiler instalados no ambiente. Portanto:
- Não há APK gerado nesta entrega.
- Não se declara compilação bem-sucedida.
- Não se declara teste em Android 12/ARM64.
- Testes de reprodução, permissões, torch, intensidade máxima, rotação, áudio/legendas e comportamento térmico ainda precisam ser feitos em dispositivo real.

## Como compilar

1. Extraia `ProtocoloZero_Projeto_Android_v0.4-fonte.zip`.
2. Abra a pasta `ProtocoloZero` no Android Studio.
3. Use JDK 17 e instale Android SDK Platform 35.
4. Aguarde a sincronização do Gradle e o download das dependências.
5. Execute `app > Tasks > build > assembleDebug` ou `gradle :app:assembleDebug`.
6. O APK debug deverá ser produzido em `app/build/outputs/apk/debug/app-debug.apk` se a compilação terminar sem erros.

Se houver erro de compilação, envie o log completo do Gradle para correção.
