package br.com.protocolozero.data

import android.content.Context
import androidx.room.Dao
import androidx.room.Database
import androidx.room.Entity
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.PrimaryKey
import androidx.room.Query
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.Transaction

@Entity(tableName = "inventory")
data class InventoryRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val description: String
)

@Entity(tableName = "checklist")
data class ChecklistRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val description: String,
    val completed: Boolean = false,
    val position: Int = 0
)

@Dao
interface ZeroDao {
    @Query("SELECT * FROM inventory ORDER BY id DESC")
    suspend fun getInventory(): List<InventoryRecord>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun addInventory(item: InventoryRecord)

    @Query("DELETE FROM inventory WHERE id = :id")
    suspend fun deleteInventory(id: Long)

    @Query("DELETE FROM inventory")
    suspend fun clearInventory()

    @Insert
    suspend fun insertInventory(items: List<InventoryRecord>)

    @Query("SELECT * FROM checklist ORDER BY position ASC, id ASC")
    suspend fun getChecklist(): List<ChecklistRecord>

    @Query("DELETE FROM checklist")
    suspend fun clearChecklist()

    @Insert
    suspend fun insertChecklist(items: List<ChecklistRecord>)

    @Transaction
    suspend fun replaceInventory(items: List<InventoryRecord>) {
        clearInventory()
        if (items.isNotEmpty()) insertInventory(items)
    }

    @Transaction
    suspend fun replaceChecklist(items: List<ChecklistRecord>) {
        clearChecklist()
        if (items.isNotEmpty()) insertChecklist(items)
    }
}

@Database(
    entities = [InventoryRecord::class, ChecklistRecord::class, OfflineMedia::class],
    version = 2,
    exportSchema = true
)
abstract class ZeroDatabase : RoomDatabase() {
    abstract fun dao(): ZeroDao
    abstract fun mediaDao(): OfflineMediaDao

    companion object {
        private val MIGRATION_1_2 = object : androidx.room.migration.Migration(1, 2) {
            override fun migrate(database: androidx.sqlite.db.SupportSQLiteDatabase) {
                database.execSQL(
                    "CREATE TABLE IF NOT EXISTS offline_media (uri TEXT NOT NULL, title TEXT NOT NULL, category TEXT NOT NULL, durationMs INTEGER NOT NULL, lastPositionMs INTEGER NOT NULL, isFavorite INTEGER NOT NULL, addedAt INTEGER NOT NULL, PRIMARY KEY(uri))"
                )
            }
        }
        @Volatile private var INSTANCE: ZeroDatabase? = null

        fun get(context: Context): ZeroDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    ZeroDatabase::class.java,
                    "protocolo_zero.db"
                ).addMigrations(MIGRATION_1_2).build().also { INSTANCE = it }
            }
    }
}


@Entity(tableName = "offline_media")
data class OfflineMedia(
    @PrimaryKey val uri: String,
    val title: String,
    val category: String = "Vídeos",
    val durationMs: Long = 0L,
    val lastPositionMs: Long = 0L,
    val isFavorite: Boolean = false,
    val addedAt: Long = System.currentTimeMillis()
)

@Dao
interface OfflineMediaDao {
    @Query("SELECT * FROM offline_media ORDER BY addedAt DESC")
    suspend fun all(): List<OfflineMedia>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun put(item: OfflineMedia)

    @Query("DELETE FROM offline_media WHERE uri = :uri")
    suspend fun delete(uri: String)

    @Query("UPDATE offline_media SET lastPositionMs = :position WHERE uri = :uri")
    suspend fun savePosition(uri: String, position: Long)

    @Query("UPDATE offline_media SET isFavorite = :favorite WHERE uri = :uri")
    suspend fun setFavorite(uri: String, favorite: Boolean)

    @Query("UPDATE offline_media SET category = :category WHERE uri = :uri")
    suspend fun setCategory(uri: String, category: String)
}
