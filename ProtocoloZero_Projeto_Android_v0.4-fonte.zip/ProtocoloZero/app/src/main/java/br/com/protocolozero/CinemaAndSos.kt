package br.com.protocolozero

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.PlayerView
import br.com.protocolozero.data.OfflineMedia
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

private val CinemaGreen = Color(0xFF65D98A)
private val CinemaPanel = Color(0xFF151D19)
private val CinemaMuted = Color(0xFF9AA9A0)

@Composable
fun CinemaOfflineScreen() {
    val context = LocalContext.current
    val dao = remember { br.com.protocolozero.data.ZeroDatabase.get(context).mediaDao() }
    val scope = rememberCoroutineScope()
    var library by remember { mutableStateOf<List<OfflineMedia>>(emptyList()) }
    var playing by remember { mutableStateOf<OfflineMedia?>(null) }
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf("Todos") }
    var message by remember { mutableStateOf("Biblioteca local • sem necessidade de internet") }

    fun refresh() { scope.launch { library = dao.all() } }
    LaunchedEffect(Unit) { refresh() }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) scope.launch {
            uris.forEach { uri ->
                try {
                    context.contentResolver.takePersistableUriPermission(uri, android.content.Intent.FLAG_GRANT_READ_URI_PERMISSION)
                    val retriever = MediaMetadataRetriever()
                    var duration = 0L
                    var title = uri.lastPathSegment?.substringAfterLast('/')?.substringAfterLast(':') ?: "Vídeo local"
                    try {
                        retriever.setDataSource(context, uri)
                        duration = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                        title = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)?.takeIf { it.isNotBlank() } ?: title
                    } catch (_: Exception) { } finally { try { retriever.release() } catch (_: Exception) { } }
                    dao.put(OfflineMedia(uri.toString(), title, durationMs = duration))
                } catch (_: Exception) { message = "Não foi possível importar um dos arquivos." }
            }
            refresh()
            message = "${uris.size} arquivo(s) adicionado(s)"
        }
    }

    Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
        Text("PROTOCOLO ZERO — CINEMA OFFLINE", color = CinemaGreen, style = MaterialTheme.typography.titleLarge)
        Text(message, color = CinemaMuted, fontSize = 11.sp)
        if (playing == null) {
            Button(onClick = { picker.launch(arrayOf("video/*")) }, modifier = Modifier.fillMaxWidth()) {
                Text("IMPORTAR VÍDEOS DO DISPOSITIVO")
            }
            OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("Pesquisar na biblioteca") })
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                listOf("Todos", "Filmes", "Séries", "Desenhos", "Vídeos").forEach { item ->
                    FilterChip(selected = filter == item, onClick = { filter = item }, label = { Text(item, fontSize = 10.sp) })
                }
            }
            LazyColumn(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                val visible = library.filter {
                    (filter == "Todos" || it.category == filter) && it.title.contains(query, true)
                }
                items(visible, key = { it.uri }) { media ->
                    Card(colors = CardDefaults.cardColors(containerColor = CinemaPanel)) {
                        Column(Modifier.fillMaxWidth().padding(12.dp)) {
                            Text(media.title, color = Color.White)
                            Text("${media.category} • ${if (media.durationMs > 0) "${media.durationMs / 60000} min" else "duração não identificada"}", color = CinemaMuted, fontSize = 10.sp)
                            var categoryMenu by remember(media.uri) { mutableStateOf(false) }
                            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                Button(onClick = { playing = media }) { Text("REPRODUZIR") }
                                OutlinedButton(onClick = {
                                    scope.launch { dao.setFavorite(media.uri, !media.isFavorite); refresh() }
                                }) { Text(if (media.isFavorite) "★ Favorito" else "☆ Favoritar") }
                                TextButton(onClick = { scope.launch { dao.delete(media.uri); refresh() } }) { Text("Remover") }
                                Box {
                                    TextButton(onClick = { categoryMenu = true }) { Text("Categoria") }
                                    DropdownMenu(expanded = categoryMenu, onDismissRequest = { categoryMenu = false }) {
                                        listOf("Filmes", "Séries", "Desenhos", "Vídeos").forEach { category ->
                                            DropdownMenuItem(text = { Text(category) }, onClick = {
                                                scope.launch { dao.setCategory(media.uri, category); refresh() }
                                                categoryMenu = false
                                            })
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                if (visible.isEmpty()) item { Text("Nenhum arquivo nesta categoria. Importe vídeos armazenados no aparelho.", color = CinemaMuted) }
            }
        } else {
            val currentMedia = playing!!
            Text(currentMedia.title, color = Color.White)
            LocalVideoPlayer(media = currentMedia, onPosition = { position ->
                scope.launch { dao.savePosition(currentMedia.uri, position) }
            })
            Button(onClick = { playing = null; refresh() }, modifier = Modifier.fillMaxWidth()) { Text("VOLTAR À BIBLIOTECA") }
            Text("A reprodução é local. Formatos e faixas disponíveis dependem dos codecs suportados pelo dispositivo.", color = CinemaMuted, fontSize = 11.sp)
        }
    }
}

@Composable
private fun LocalVideoPlayer(media: OfflineMedia, onPosition: (Long) -> Unit) {
    val context = LocalContext.current
    val activity = context as? android.app.Activity
    var volume by remember(media.uri) { mutableFloatStateOf(1f) }
    var brightness by remember(media.uri) { mutableFloatStateOf(0.75f) }
    var speed by remember(media.uri) { mutableFloatStateOf(1f) }
    val originalBrightness = remember(media.uri) { activity?.window?.attributes?.screenBrightness ?: -1f }
    val player = remember(media.uri) {
        ExoPlayer.Builder(context).build().apply {
            setMediaItem(MediaItem.fromUri(Uri.parse(media.uri)))
            prepare()
            if (media.lastPositionMs > 0) seekTo(media.lastPositionMs)
            playWhenReady = true
        }
    }
    LaunchedEffect(brightness) {
        activity?.window?.let { window ->
            val attrs = window.attributes
            attrs.screenBrightness = brightness
            window.attributes = attrs
        }
    }
    LaunchedEffect(player) {
        while (isActive) {
            delay(5000L)
            onPosition(player.currentPosition)
        }
    }
    DisposableEffect(player) {
        onDispose {
            onPosition(player.currentPosition)
            player.release()
            activity?.window?.let { window ->
                val attrs = window.attributes
                attrs.screenBrightness = originalBrightness
                window.attributes = attrs
            }
        }
    }
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        AndroidView(
            factory = { ctx -> PlayerView(ctx).apply { this.player = player; useController = true } },
            modifier = Modifier.fillMaxWidth().aspectRatio(16f / 9f)
        )
        Text("Volume", color = CinemaMuted, fontSize = 10.sp)
        Slider(value = volume, onValueChange = { volume = it; player.volume = it }, valueRange = 0f..1f)
        Text("Brilho da tela", color = CinemaMuted, fontSize = 10.sp)
        Slider(value = brightness, onValueChange = { brightness = it }, valueRange = 0.05f..1f)
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Velocidade", color = CinemaMuted, fontSize = 10.sp)
            listOf(0.5f, 1f, 1.25f, 1.5f, 2f).forEach { value ->
                FilterChip(selected = speed == value, onClick = { speed = value; player.setPlaybackSpeed(value) }, label = { Text("${value}x", fontSize = 9.sp) })
            }
        }
        Text("Posição salva automaticamente a cada 5 segundos. Controles de faixa de áudio/legenda dependem do arquivo e dos recursos exibidos pelo player.", color = CinemaMuted, fontSize = 10.sp)
    }
}

@Composable
fun SosExtremeScreen() {
    val context = LocalContext.current
    val activity = context as? android.app.Activity
    val manager = remember { context.getSystemService(Context.CAMERA_SERVICE) as CameraManager }
    var flashId by remember { mutableStateOf<String?>(null) }
    var flashOn by remember { mutableStateOf(false) }
    var mode by remember { mutableStateOf("OFF") }
    var lightOn by remember { mutableStateOf(false) }
    var colorName by remember { mutableStateOf("Vermelho") }
    var error by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()
    val colors = mapOf("Vermelho" to Color.Red, "Azul" to Color.Blue, "Amarelo" to Color.Yellow, "Branco" to Color.White)
    val permission = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            flashId = try { manager.cameraIdList.firstOrNull {
                manager.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } } catch (_: Exception) { null }
            if (flashId == null) error = "Este aparelho não disponibiliza flash traseiro."
        } else error = "Permissão de câmera negada; o flash não pode ser utilizado."
    }

    fun setTorch(enabled: Boolean) {
        try {
            val id = flashId ?: manager.cameraIdList.firstOrNull {
                manager.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            } ?: run { error = "Flash não disponível neste aparelho."; return }
            flashId = id
            if (enabled && Build.VERSION.SDK_INT >= 33) {
                try {
                    val max = manager.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_STRENGTH_MAXIMUM_LEVEL) ?: 1
                    manager.turnOnTorchWithStrengthLevel(id, max.coerceAtLeast(1))
                } catch (_: Exception) { manager.setTorchMode(id, true) }
            } else manager.setTorchMode(id, enabled)
            flashOn = enabled
        } catch (_: SecurityException) { error = "Permissão de câmera necessária." }
        catch (_: Exception) { error = "O hardware não conseguiu alterar o estado do flash." }
    }

    DisposableEffect(Unit) {
        onDispose {
            try { flashId?.let { manager.setTorchMode(it, false) } } catch (_: Exception) { }
        }
    }

    LaunchedEffect(mode) {
        if (mode == "SOS_FLASH" || mode == "SOS_SCREEN" || mode == "SOS_COMBINED") {
            val sequence = listOf("...", "---", "...")
            while (isActive && mode != "OFF") {
                sequence.forEach { letter ->
                    letter.forEachIndexed { index, symbol ->
                        lightOn = true
                        if (mode != "SOS_SCREEN") setTorch(true)
                        delay(if (symbol == '.') 200L else 600L)
                        lightOn = false
                        if (mode != "SOS_SCREEN") setTorch(false)
                        if (index < letter.lastIndex) delay(200L)
                    }
                    delay(600L)
                }
                delay(1400L)
            }
        } else {
            lightOn = false
            if (flashOn) setTorch(false)
        }
    }

    val screenColor = if (lightOn && mode != "SOS_FLASH") colors[colorName] ?: Color.Red else Color.Black
    Column(Modifier.fillMaxSize().background(screenColor).padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text("LANTERNA SOS EXTREMA", color = if (lightOn) Color.Black else Color.White, style = MaterialTheme.typography.titleLarge)
        Text("Estado do flash: ${if (flashOn) "LIGADO" else "DESLIGADO"}", color = if (lightOn) Color.Black else CinemaMuted)
        if (error.isNotBlank()) Text(error, color = Color(0xFFFF7777))
        Button(onClick = {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) permission.launch(Manifest.permission.CAMERA)
            else {
                if (mode != "OFF") mode = "OFF"
                setTorch(!flashOn)
            }
        }, modifier = Modifier.fillMaxWidth()) { Text(if (flashOn) "DESLIGAR POTÊNCIA MÁXIMA" else "POTÊNCIA MÁXIMA") }

        Button(onClick = {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                permission.launch(Manifest.permission.CAMERA)
                error = "Autorize a câmera e toque novamente em ATIVAR SOS."
            } else {
                mode = if (mode == "SOS_FLASH") "OFF" else "SOS_FLASH"
            }
        }, modifier = Modifier.fillMaxWidth()) { Text("ATIVAR SOS • FLASH") }

        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf("Vermelho", "Azul", "Amarelo", "Branco").forEach { name ->
                FilterChip(selected = colorName == name, onClick = { colorName = name }, label = { Text(name, fontSize = 9.sp) })
            }
        }
        Button(onClick = { mode = if (mode == "SOS_SCREEN") "OFF" else "SOS_SCREEN" }, modifier = Modifier.fillMaxWidth()) {
            Text("SOS COLORIDO PELA TELA")
        }
        Button(onClick = {
            if (ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
                permission.launch(Manifest.permission.CAMERA)
                error = "Autorize a câmera e toque novamente em SOS COMBINADO."
            } else mode = if (mode == "SOS_COMBINED") "OFF" else "SOS_COMBINED"
        }, modifier = Modifier.fillMaxWidth()) { Text("SOS COMBINADO") }
        Button(onClick = { mode = "OFF"; lightOn = false; setTorch(false) }, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB3261E))) {
            Text("PARAR SOS")
        }
        Text("SOS — PRECISO DE AJUDA", color = if (lightOn) Color.Black else Color.White, style = MaterialTheme.typography.titleMedium)
        Text("... --- ...", color = if (lightOn) Color.Black else CinemaGreen, style = MaterialTheme.typography.headlineMedium)
        Text("O flash traseiro permanece branco. As cores são exibidas somente pela tela. Evite olhar diretamente para luzes intermitentes. A sinalização pode consumir bateria e aquecer o aparelho.", color = if (lightOn) Color.Black else CinemaMuted, fontSize = 11.sp)
        Text("A temporização é aproximada; interrompa se o aparelho aquecer.", color = if (lightOn) Color.Black else CinemaMuted, fontSize = 10.sp)
    }
}
